#pragma once
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <ctime>
#include "searchnode.h"
#include <vector>

class Debugger
{
private:
	int eventCount = 0;
	std::stringstream saveData;
	std::vector<std::string> svgKeys = {"node","gridSpace","AnyaNode"};
	std::string getDataString(float g, float f, std::string pId,bool comma);
	std::string getSvgString(std::string svg,int variableCount,std::string svgVariables[]);
	
public:
    Debugger();

    void AddStartEvent(std::string startId,std::string endId);

	void AddEndEvent(std::string endId);

	void AddGenerateEvent(std::string id, float g, float f,std::string parentId,std::string svg,int variableCount,std::string svgVariables[]);

	void AddGenerateEvent(std::string id, float x, float y, float g, float f,std::string parentId,std::string svg,int variableCount,std::string svgVariables[]);

	void AddUpdateEvent(std::string id, int g, int f, std::string parentId);

	void AddExpandingEvent(std::string id);

	void AddClosingEvent(std::string id);

    void printToDebugFile();

};
