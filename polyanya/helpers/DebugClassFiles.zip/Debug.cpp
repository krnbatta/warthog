#include "Debug.h"
#include <algorithm>
using namespace std;



string Debugger::getDataString(float g, float f, string pId,bool comma)
{
	stringstream dataStream;
	
	if(pId == "None")
		dataStream << "\"pId\": null ,";
	else
		dataStream << "\"pId\":\"" << pId<<"\",";

	dataStream <<"\"g\":" << g << ","
			   << "\"f\":" << f;
	if(comma)
		dataStream << ",";

	
	return dataStream.str();
}
string Debugger::getSvgString(std::string svg,int variableCount,std::string svgVariables[])
{
	stringstream svgStream;
	if(find(svgKeys.begin(),svgKeys.end(),svg) != svgKeys.end())
	{
		//If it is found in svgKeys then we must record it as svgType and take note of Variables
		svgStream << "\"svgType\":\"" << svg << "\",";
		svgStream << "\"variables\":[";
		
		if(svgVariables != NULL)
		{
			for(int i = 0; i < variableCount;i++)
			{
				if(i != 0) svgStream << ',';
				svgStream << "\""<<svgVariables[i] << "\"";
			}
		}
		svgStream<<"]";
	}
	else
	{
		//If not in svgKeys then it will be svg so just note it as svg
		svgStream<<"\"svg\":" << svg;
	}
	return svgStream.str();
}

Debugger::Debugger()
{
	saveData << "{ \"Map\" : \"Null\", "
			 << "\"eventList\" : [ \n";
}
void Debugger::AddStartEvent(string startId,string endId)
{
	if(eventCount != 0)
			saveData<<", \n";
		saveData << "\t { \"type\" : \"start\","
				 << "\"start\":\"" << startId<<"\","<< "\"end\":\"" << endId << "\"" 
				 << "}";
		eventCount++;
}
void Debugger::AddEndEvent(string endId)
{
	if(eventCount != 0)
			saveData<<", \n";
		saveData << "\t {\"type\":\"end\", \"id\":\""<<endId<<"\"}";
}

void Debugger::AddGenerateEvent(string id, float x, float y, float g, float f,string parentId,string svg,int variableCount,string svgVariables[]=NULL)
{
	saveData << "\t {\"type\":\"generating\","
				 << "\"id\": \"" << id << "\"" << ","
				 << "\"x\":" << x << ","
				 << "\"y\":" << y <<","
				 << getDataString(g,f,parentId,true)
				 << getSvgString(svg,variableCount,svgVariables)
		   		 << " }";
	eventCount++;
	
}
void Debugger::AddGenerateEvent(string id, float g, float f,string parentId,string svg,int variableCount,string svgVariables[]=NULL)
{
	saveData << "\t {\"type\":\"generating\","
				 << "\"id\": \"" << id << "\""<< ","
				 << getDataString(g,f,parentId,true)
				 << getSvgString(svg,variableCount,svgVariables)
			  	 << " }";
	eventCount++;
	
}


void Debugger::AddUpdateEvent(string id, int g, int f, string parentId)
{
	saveData << "\t {\"type\":\"updating\","
				 << "\"id\": \"" << id << "\""<< ","
				 << getDataString(g,f,parentId,false) << " }";
	eventCount++;
}

void Debugger::AddExpandingEvent(string id)
{
	saveData << "\t {\"type\":\"expanding\","
				 << "\"id\": \"" << id << "\"" << "}";
	eventCount++;
}

void Debugger::AddClosingEvent(string id)
{
	saveData << "\t {\"type\":\"closing\","
				 << "\"id\": \"" << id << "\"}";
	eventCount++;
}

void Debugger::printToDebugFile()
{
	std::ofstream outputfile; //open and save the file
				
		std::time_t t = time(0);
		struct tm * now = localtime(&t);
		std::string strFileName = "Debug:";
		strFileName.append(asctime(now));
		strFileName.append(".json");
		outputfile.open(strFileName);
		saveData << "\n ] }";	
		
		std::string data = saveData.str();
		outputfile << data;
		outputfile.close();
	
}
